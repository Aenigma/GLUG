This is an archive of the original content I created during my time doing
GLUG/Unix Club during high school.

The stuff written here is unprofessional, has a very narrow scope, and may,
in fact, be out of date, wrong, or otherwise rather stupid. Some of the content
may be opiniated with statements that no longer even represent what I believe
now, so take them with a grain of salt (like you should with any opinion, really
). That being said, it may be more newbie friendly than the first result you may
get on google and, thus, may be valuable.

Almost all the content has been written in vim, OpenOffice, or Microsoft
Office 2003, depending on the environment which was most convenient for me at
the time of writing. I typically had converted the documents to PDF and printed
them for portability amongst my enviroments but I chose not to include them here
to avoid confusion regarding redundant documents. I made sure, however, that all
the documents would be available to you if you had OpenOffice and a you have a
text editor which can handle both UNIX and DOS style line endings such as
notepad++ or vim.

Also, you may find copyright notices on some of them. Just ignore them.
Everything here is public domain.

nullindev@gmail.com
